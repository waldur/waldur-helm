{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "waldur.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "waldur.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "waldur.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "waldur.labels" -}}
app.kubernetes.io/name: {{ include "waldur.name" . }}
helm.sh/chart: {{ include "waldur.chart" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Set postgres version
*/}}
{{- define "waldur.postgresql.version" -}}
17
{{- end -}}

{{/*
Set postgres host
*/}}
{{- define "waldur.postgresql.host" -}}
{{- if .Values.externalDB.enabled -}}
{{ .Values.externalDB.serviceName }}
{{- else if .Values.postgresqlha.enabled -}}
"{{ .Release.Name }}-postgresqlha-pgpool"
{{- else if .Values.postgresql.enabled -}}
"{{ .Release.Name }}-postgresql"
{{- else -}}
"postgresql-waldur"
{{- end -}}
{{- end -}}

{{/*
Set postgres port
*/}}
{{- define "waldur.postgresql.port" -}}
"5432"
{{- end -}}

{{/*
Set postgres secret
*/}}
{{- define "waldur.postgresql.secret" -}}
{{- if .Values.externalDB.enabled -}}
{{ .Values.externalDB.secretName }}
{{- else if .Values.postgresqlha.enabled -}}
"{{ .Release.Name }}-postgresqlha-postgresql"
{{- else if .Values.postgresql.enabled -}}
"{{ .Release.Name }}-postgresql"
{{- else -}}
"postgresql-waldur"
{{- end -}}
{{- end -}}

{{/*
Set postgres secret password key
*/}}
{{- define "waldur.postgresql.secret.passwordKey" -}}
"password"
{{- end -}}

{{/*
Set postgres database name
*/}}
{{- define "waldur.postgresql.dbname" -}}
{{- if .Values.postgresqlha.enabled -}}
{{ .Values.postgresqlha.postgresql.database | quote }}
{{- else if .Values.postgresql.enabled -}}
{{ .Values.postgresql.auth.database | quote }}
{{- else if and .Values.externalDB.enabled .Values.externalDB.database -}}
{{ .Values.externalDB.database | quote }}
{{- else -}}
"waldur"
{{- end -}}
{{- end -}}

{{/*
Set postgres user
*/}}
{{- define "waldur.postgresql.user" -}}
{{- if .Values.postgresqlha.enabled -}}
{{ .Values.postgresqlha.postgresql.username | quote }}
{{- else if .Values.postgresql.enabled -}}
{{ .Values.postgresql.auth.username | quote }}
{{- else if and .Values.externalDB.enabled .Values.externalDB.username -}}
{{ .Values.externalDB.username | quote }}
{{- else -}}
"waldur"
{{- end -}}
{{- end -}}

{{/*
Set rabbitmq host
*/}}
{{- define "waldur.rabbitmq.rmqHost" -}}
{{- $rmqHost := "" -}}
{{- if .Values.rabbitmq.enabled -}}
{{- $rmqHost = list .Release.Name "rabbitmq" | join "-" -}}
{{- else -}}
{{- $rmqHost = .Values.rabbitmq.host -}}
{{- end -}}
{{ $rmqHost }}
{{- end -}}


{{/*
Render a component's extraEnvVars list.
Usage: {{- include "waldur.extraEnvVars" .Values.api | nindent 12 }}
*/}}
{{- define "waldur.extraEnvVars" -}}
{{- with .extraEnvVars -}}
{{ toYaml . }}
{{- end -}}
{{- end -}}

{{/*
Render a component's envFrom entries from extraEnvVarsCM / extraEnvVarsSecret.
Skip the call site's envFrom: block entirely when both are empty.
Usage:
  {{- $envFrom := include "waldur.extraEnvFrom" .Values.api -}}
  {{- if $envFrom }}
  envFrom:
  {{- $envFrom | nindent 12 }}
  {{- end }}
*/}}
{{- define "waldur.extraEnvFrom" -}}
{{- if .extraEnvVarsCM }}
- configMapRef:
    name: {{ .extraEnvVarsCM }}
{{- end }}
{{- if .extraEnvVarsSecret }}
- secretRef:
    name: {{ .extraEnvVarsSecret }}
{{- end }}
{{- end -}}

{{/*
Render a component's extraVolumes list.
Usage: {{- include "waldur.extraVolumes" .Values.api | nindent 6 }}
*/}}
{{- define "waldur.extraVolumes" -}}
{{- with .extraVolumes -}}
{{ toYaml . }}
{{- end -}}
{{- end -}}

{{/*
Render a component's extraVolumeMounts list.
Usage: {{- include "waldur.extraVolumeMounts" .Values.api | nindent 12 }}
*/}}
{{- define "waldur.extraVolumeMounts" -}}
{{- with .extraVolumeMounts -}}
{{ toYaml . }}
{{- end -}}
{{- end -}}

{{/*
Render .Values.ingress.annotations as YAML key/value pairs, already indented
to sit inside an Ingress metadata.annotations block. Emits nothing when the
map is empty so the baseline render stays byte-identical.
Used by every ingress template so operators can add cross-cutting annotations
(e.g. external-dns.alpha.kubernetes.io/ttl: "60") without forking the chart.
Usage: {{- include "waldur.ingressAnnotations" . }}
*/}}
{{- define "waldur.ingressAnnotations" -}}
{{- with .Values.ingress.annotations -}}
{{- toYaml . | nindent 4 -}}
{{- end -}}
{{- end -}}

{{/*
Assemble GUNICORN_CMD_ARGS value from .Values.gunicorn.*. Returns empty when no field is set.
Usage:
  {{- $gun := include "waldur.gunicornCmdArgs" . -}}
  {{- if $gun }}
  - name: GUNICORN_CMD_ARGS
    value: {{ $gun | quote }}
  {{- end }}
*/}}
{{- define "waldur.gunicornCmdArgs" -}}
{{- $parts := list -}}
{{- with .Values.gunicorn -}}
{{- if .timeout }}{{- $parts = append $parts (printf "--timeout %v" .timeout) -}}{{- end -}}
{{- if .gracefulTimeout }}{{- $parts = append $parts (printf "--graceful-timeout %v" .gracefulTimeout) -}}{{- end -}}
{{- if .workers }}{{- $parts = append $parts (printf "--workers %v" .workers) -}}{{- end -}}
{{- if .keepalive }}{{- $parts = append $parts (printf "--keep-alive %v" .keepalive) -}}{{- end -}}
{{- if .maxRequests }}{{- $parts = append $parts (printf "--max-requests %v" .maxRequests) -}}{{- end -}}
{{- if .maxRequestsJitter }}{{- $parts = append $parts (printf "--max-requests-jitter %v" .maxRequestsJitter) -}}{{- end -}}
{{- if .extraArgs }}{{- $parts = append $parts .extraArgs -}}{{- end -}}
{{- end -}}
{{- join " " $parts -}}
{{- end -}}

{{/*
Add environment variables to configure private database
*/}}
{{- define "waldur.env.initdb" -}}
- name: PGHOST
  value: {{ include "waldur.postgresql.host" . }}

- name: PGPORT
  value: {{ include "waldur.postgresql.port" . }}

- name: PGUSER
  value: {{ include "waldur.postgresql.user" . }}

- name: PGDATABASE
  value: {{ include "waldur.postgresql.dbname" . }}

- name: PGPASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "waldur.postgresql.secret" . }}
      key: {{ include "waldur.postgresql.secret.passwordKey" . }}
{{- end -}}

{{/*
Add environment variables to configure database values and Sentry environment
*/}}
{{- define "waldur.credentials" -}}
- name: GLOBAL_SECRET_KEY
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.secretKeyExistingSecret.name | default "waldur-secret" }}
      key: {{ .Values.waldur.secretKeyExistingSecret.key | default "GLOBAL_SECRET_KEY" }}

- name: POSTGRESQL_HOST
  value: {{ include "waldur.postgresql.host" . }}

- name: POSTGRESQL_PORT
  value: {{ include "waldur.postgresql.port" . }}

- name: POSTGRESQL_USER
{{ if and .Values.externalDB.enabled (not .Values.externalDB.username) }}
  valueFrom:
    secretKeyRef:
      name: {{ include "waldur.postgresql.secret" . }}
      key: username
{{ else }}
  value: {{ include "waldur.postgresql.user" . }}
{{ end }}

- name: POSTGRESQL_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "waldur.postgresql.secret" . }}
      key: {{ include "waldur.postgresql.secret.passwordKey" . }}

- name: POSTGRESQL_NAME
  value: {{ include "waldur.postgresql.dbname" . }}

{{ if .Values.readonlyDB.enabled }}
- name: POSTGRESQL_READONLY_USER
  {{ if .Values.readonlyDB.username }}
  valueFrom:
    secretKeyRef:
      name: waldur-secret
      key: READONLY_DB_USERNAME
  {{ else }}
  value: {{ include "waldur.postgresql.user" . }}
  {{ end }}

- name: POSTGRESQL_READONLY_PASSWORD
  {{ if .Values.readonlyDB.passwordExistingSecret.name }}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.readonlyDB.passwordExistingSecret.name }}
      key: {{ .Values.readonlyDB.passwordExistingSecret.key | default "READONLY_DB_PASSWORD" }}
  {{ else if .Values.readonlyDB.password }}
  valueFrom:
    secretKeyRef:
      name: waldur-secret
      key: READONLY_DB_PASSWORD
  {{ else }}
  valueFrom:
    secretKeyRef:
      name: {{ include "waldur.postgresql.secret" . }}
      key: {{ include "waldur.postgresql.secret.passwordKey" . }}
  {{ end }}
{{ end }}

{{/*
Temporarily disabled as it crashes deployments with ansible installer
{{ if or (and .Values.waldur.mail.username (ne .Values.waldur.mail.username "")) (and .Values.waldur.mail.existingSecret.name (ne .Values.waldur.mail.existingSecret.name "")) }}
- name: EMAIL_USER
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.mail.existingSecret.name | default "waldur-secret" }}
      key: {{ .Values.waldur.mail.existingSecret.userKey | default "MAIL_USER" }}

- name: EMAIL_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.mail.existingSecret.name | default "waldur-secret"}}
      key: {{ .Values.waldur.mail.existingSecret.passwordKey | default "MAIL_PASSWORD"}}
{{ end }}
*/}}

- name: RABBITMQ_HOSTNAME
  value: {{ include "waldur.rabbitmq.rmqHost" . | quote }}
- name: RABBITMQ_USERNAME
  {{ if and .Values.rabbitmq.secret.name .Values.rabbitmq.secret.usernameKey }}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.rabbitmq.secret.name }}
      key: {{ .Values.rabbitmq.secret.usernameKey }}
  {{ else if and (hasKey .Values.rabbitmq.auth "existingSecret") .Values.rabbitmq.auth.existingSecret.name }}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.rabbitmq.auth.existingSecret.name }}
      key: {{ .Values.rabbitmq.auth.existingSecret.usernameKey }}
  {{ else }}
  valueFrom:
    secretKeyRef:
      name: "waldur-secret"
      key: "RABBITMQ_USER"
  {{ end }}
- name: RABBITMQ_PASSWORD
  {{ if and .Values.rabbitmq.secret.name .Values.rabbitmq.secret.passwordKey }}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.rabbitmq.secret.name }}
      key: {{ .Values.rabbitmq.secret.passwordKey }}
  {{ else if and (hasKey .Values.rabbitmq.auth "existingSecret") .Values.rabbitmq.auth.existingSecret.name }}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.rabbitmq.auth.existingSecret.name }}
      key: {{ .Values.rabbitmq.auth.existingSecret.passwordKey }}
  {{ else }}
  valueFrom:
    secretKeyRef:
      name: "waldur-secret"
      key: "RABBITMQ_PASSWORD"
  {{ end }}

{{ if .Values.waldur.sentryDSN }}
- name: SENTRY_DSN
  value: {{ .Values.waldur.sentryDSN | quote }}

- name: SENTRY_ENVIRONMENT
  valueFrom:
    fieldRef:
      fieldPath: metadata.namespace
{{ end }}

{{- if .Values.waldur.remoteEduteams.existingSecret.name -}}
- name: REMOTE_EDUTEAMS_REFRESH_TOKEN
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.refreshTokenKey }}
- name: REMOTE_EDUTEAMS_CLIENT_ID
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.clientIDKey }}
- name: REMOTE_EDUTEAMS_SECRET
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.clientSecretKey }}
- name: REMOTE_EDUTEAMS_USERINFO_URL
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.userinfoUrlKey }}
- name: REMOTE_EDUTEAMS_TOKEN_URL
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.tokenUrlKey }}
- name: REMOTE_EDUTEAMS_SSH_API_URL
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.sshApiUrlKey }}
- name: REMOTE_EDUTEAMS_SSH_API_USERNAME
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.sshApiUsernameKey }}
- name: REMOTE_EDUTEAMS_SSH_API_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.sshApiPasswordKey }}
{{- end -}}

{{- if .Values.waldur.ldap.passwordExistingSecret.name -}}
- name: AUTH_LDAP_BIND_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.ldap.passwordExistingSecret.name }}
      key: {{ .Values.waldur.ldap.passwordExistingSecret.key }}
{{- end -}}

{{- $pidDatacitePasswordSecret := dig "pid_datacite" "passwordSecret" (dict) .Values.waldur -}}
{{- if and (get $pidDatacitePasswordSecret "name") (get $pidDatacitePasswordSecret "key") }}
- name: DATACITE_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ get $pidDatacitePasswordSecret "name" }}
      key: {{ get $pidDatacitePasswordSecret "key" }}
{{- else if .Values.waldur.pid_datacite.password }}
- name: DATACITE_PASSWORD
  valueFrom:
    secretKeyRef:
      name: waldur-secret
      key: DATACITE_PASSWORD
{{- end -}}

{{- if .Values.waldur.paypal.existingSecret.name -}}
- name: PAYPAL_SECRET
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.paypal.existingSecret.name }}
      key: {{ .Values.waldur.paypal.existingSecret.secretKey }}
{{- end -}}

{{ if .Values.proxy.httpsProxy }}
- name: https_proxy
  value: {{ .Values.proxy.httpsProxy | quote }}
{{ end }}

{{ if .Values.proxy.httpProxy }}
- name: http_proxy
  value: {{ .Values.proxy.httpProxy | quote }}
{{ end }}

{{ if .Values.proxy.noProxy }}
- name: no_proxy
  value: {{ .Values.proxy.noProxy | quote }}
{{ end }}
{{- end -}}

{{/*
Determine imagePullPolicy based on image tag.
If tag is "latest", use "Always", otherwise use configured pullPolicy.
*/}}
{{- define "waldur.imagePullPolicy" -}}
{{- $tag := .tag -}}
{{- if eq $tag "latest" -}}
Always
{{- else -}}
{{ .Values.waldur.pullPolicy }}
{{- end -}}
{{- end -}}

{{/*
Determine imagePullPolicy based on full image string (image:tag).
If tag is "latest", use "Always", otherwise use configured pullPolicy.
*/}}
{{- define "waldur.imagePullPolicyFromImage" -}}
{{- $image := .image -}}
{{- $parts := splitList ":" $image -}}
{{- $tag := "latest" -}}
{{- if gt (len $parts) 1 -}}
{{- $tag = last $parts -}}
{{- end -}}
{{- if eq $tag "latest" -}}
Always
{{- else -}}
{{ .Values.waldur.pullPolicy }}
{{- end -}}
{{- end -}}
