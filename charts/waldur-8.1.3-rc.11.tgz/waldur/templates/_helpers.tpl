{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "waldur.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "waldur.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "waldur.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "waldur.labels" -}}
app.kubernetes.io/name: {{ include "waldur.name" . }}
helm.sh/chart: {{ include "waldur.chart" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Set postgres version
*/}}
{{- define "waldur.postgresql.version" -}}
17
{{- end -}}

{{/*
Set postgres host
*/}}
{{- define "waldur.postgresql.host" -}}
{{- if .Values.externalDB.enabled -}}
{{ .Values.externalDB.serviceName }}
{{- else if .Values.postgresql.enabled -}}
"{{ .Release.Name }}-postgresql"
{{- else -}}
"postgresql-waldur"
{{- end -}}
{{- end -}}

{{/*
Set postgres port
*/}}
{{- define "waldur.postgresql.port" -}}
"5432"
{{- end -}}

{{/*
Set postgres secret
*/}}
{{- define "waldur.postgresql.secret" -}}
{{- if .Values.externalDB.enabled -}}
{{ .Values.externalDB.secretName }}
{{- else if .Values.postgresql.enabled -}}
"{{ .Release.Name }}-postgresql"
{{- else -}}
"postgresql-waldur"
{{- end -}}
{{- end -}}

{{/*
Set postgres secret password key.

The bundled subchart generates its admin secret with the key
"postgres-password". Operator-managed secrets differ: both CloudNativePG's
<cluster>-app secret and Zalando's *.credentials.postgresql.acid.zalan.do use
"password", which is the default for externalDB.passwordKey.
*/}}
{{- define "waldur.postgresql.secret.passwordKey" -}}
{{- if .Values.externalDB.enabled -}}
{{ .Values.externalDB.passwordKey | default "password" | quote }}
{{- else if .Values.postgresql.enabled -}}
"postgres-password"
{{- else -}}
"password"
{{- end -}}
{{- end -}}

{{/*
Set postgres database name
*/}}
{{- define "waldur.postgresql.dbname" -}}
{{- if .Values.postgresql.enabled -}}
{{ .Values.postgresql.auth.database | quote }}
{{- else if and .Values.externalDB.enabled .Values.externalDB.database -}}
{{ .Values.externalDB.database | quote }}
{{- else -}}
"waldur"
{{- end -}}
{{- end -}}

{{/*
Set postgres user
*/}}
{{- define "waldur.postgresql.user" -}}
{{- if .Values.postgresql.enabled -}}
{{ .Values.postgresql.auth.username | quote }}
{{- else if and .Values.externalDB.enabled .Values.externalDB.username -}}
{{ .Values.externalDB.username | quote }}
{{- else -}}
"waldur"
{{- end -}}
{{- end -}}

{{/*
Set rabbitmq host
*/}}
{{- define "waldur.rabbitmq.rmqHost" -}}
{{- $rmqHost := "" -}}
{{- if .Values.rabbitmq.enabled -}}
{{- $rmqHost = list .Release.Name "rabbitmq" | join "-" -}}
{{- else -}}
{{- $rmqHost = .Values.rabbitmq.host -}}
{{- end -}}
{{ $rmqHost }}
{{- end -}}


{{/*
Render a component's extraEnvVars list.
Usage: {{- include "waldur.extraEnvVars" .Values.api | nindent 12 }}
*/}}
{{- define "waldur.extraEnvVars" -}}
{{- with .extraEnvVars -}}
{{ toYaml . }}
{{- end -}}
{{- end -}}

{{/*
Render a component's envFrom entries from extraEnvVarsCM / extraEnvVarsSecret.
Skip the call site's envFrom: block entirely when both are empty.
Usage:
  {{- $envFrom := include "waldur.extraEnvFrom" .Values.api -}}
  {{- if $envFrom }}
  envFrom:
  {{- $envFrom | nindent 12 }}
  {{- end }}
*/}}
{{- define "waldur.extraEnvFrom" -}}
{{- if .extraEnvVarsCM }}
- configMapRef:
    name: {{ .extraEnvVarsCM }}
{{- end }}
{{- if .extraEnvVarsSecret }}
- secretRef:
    name: {{ .extraEnvVarsSecret }}
{{- end }}
{{- end -}}

{{/*
Render a component's extraVolumes list.
Usage: {{- include "waldur.extraVolumes" .Values.api | nindent 6 }}
*/}}
{{- define "waldur.extraVolumes" -}}
{{- with .extraVolumes -}}
{{ toYaml . }}
{{- end -}}
{{- end -}}

{{/*
Render a component's extraVolumeMounts list.
Usage: {{- include "waldur.extraVolumeMounts" .Values.api | nindent 12 }}
*/}}
{{- define "waldur.extraVolumeMounts" -}}
{{- with .extraVolumeMounts -}}
{{ toYaml . }}
{{- end -}}
{{- end -}}

{{/*
Render .Values.ingress.annotations as YAML key/value pairs, already indented
to sit inside an Ingress metadata.annotations block. Emits nothing when the
map is empty so the baseline render stays byte-identical.
Used by every ingress template so operators can add cross-cutting annotations
(e.g. external-dns.alpha.kubernetes.io/ttl: "60") without forking the chart.
Usage: {{- include "waldur.ingressAnnotations" . }}
*/}}
{{- define "waldur.ingressAnnotations" -}}
{{- with .Values.ingress.annotations -}}
{{- toYaml . | nindent 4 -}}
{{- end -}}
{{- end -}}

{{/*
Fail fast when gatewayAPI.enabled but the target cluster doesn't advertise the
Gateway API CRDs -- a clearer error than the apiserver's own "no matches for
kind HTTPRoute" during apply. Against a real cluster, .Capabilities.APIVersions
reflects what's actually installed; `helm template`/`helm lint` need an
explicit `--api-versions gateway.networking.k8s.io/v1/HTTPRoute` to simulate
that (see waldur/test/values-gateway.yaml usage in .gitlab-ci.yml).
Usage: {{- include "waldur.gatewayAPI.assertAvailable" . }}
*/}}
{{- define "waldur.gatewayAPI.assertAvailable" -}}
{{- if not (.Capabilities.APIVersions.Has "gateway.networking.k8s.io/v1/HTTPRoute") -}}
{{- fail "gatewayAPI.enabled is true, but the Gateway API CRDs (gateway.networking.k8s.io/v1) are not installed on the target cluster. Install them first: https://gateway-api.sigs.k8s.io/guides/#installing-gateway-api" -}}
{{- end -}}
{{- end -}}

{{/*
Render the parentRefs list for a chart-managed HTTPRoute: the chart's own
Gateway when gatewayAPI.createGateway is true, otherwise the operator-supplied
gatewayAPI.parentRefs (required non-empty in that case -- an HTTPRoute with no
parentRefs never attaches anywhere).
Usage:
  spec:
    parentRefs:
      {{- include "waldur.gatewayAPI.parentRefs" . | nindent 4 }}
*/}}
{{- define "waldur.gatewayAPI.parentRefs" -}}
{{- if .Values.gatewayAPI.createGateway -}}
- name: {{ include "waldur.fullname" . }}-gateway
{{- else if .Values.gatewayAPI.parentRefs -}}
{{- toYaml .Values.gatewayAPI.parentRefs -}}
{{- else -}}
{{- fail "gatewayAPI.enabled is true, but neither gatewayAPI.parentRefs nor gatewayAPI.createGateway is set -- HTTPRoutes need a Gateway to attach to." -}}
{{- end -}}
{{- end -}}

{{/*
Render .Values.gatewayAPI.annotations as YAML, for callers to nindent under
their own metadata.annotations. Emits nothing when the map is empty -- guard
with `if .Values.gatewayAPI.annotations` at the call site so an empty map
doesn't leave a dangling "annotations:" key.
Usage:
  {{- if .Values.gatewayAPI.annotations }}
  annotations:
    {{- include "waldur.gatewayAPI.annotations" . | nindent 4 }}
  {{- end }}
*/}}
{{- define "waldur.gatewayAPI.annotations" -}}
{{- toYaml .Values.gatewayAPI.annotations -}}
{{- end -}}

{{/*
Assemble GUNICORN_CMD_ARGS value from .Values.gunicorn.*. Returns empty when no field is set.
Usage:
  {{- $gun := include "waldur.gunicornCmdArgs" . -}}
  {{- if $gun }}
  - name: GUNICORN_CMD_ARGS
    value: {{ $gun | quote }}
  {{- end }}
*/}}
{{- define "waldur.gunicornCmdArgs" -}}
{{- $parts := list -}}
{{- with .Values.gunicorn -}}
{{- if .timeout }}{{- $parts = append $parts (printf "--timeout %v" .timeout) -}}{{- end -}}
{{- if .gracefulTimeout }}{{- $parts = append $parts (printf "--graceful-timeout %v" .gracefulTimeout) -}}{{- end -}}
{{- if .workers }}{{- $parts = append $parts (printf "--workers %v" .workers) -}}{{- end -}}
{{- if .keepalive }}{{- $parts = append $parts (printf "--keep-alive %v" .keepalive) -}}{{- end -}}
{{- if .maxRequests }}{{- $parts = append $parts (printf "--max-requests %v" .maxRequests) -}}{{- end -}}
{{- if .maxRequestsJitter }}{{- $parts = append $parts (printf "--max-requests-jitter %v" .maxRequestsJitter) -}}{{- end -}}
{{- if .extraArgs }}{{- $parts = append $parts .extraArgs -}}{{- end -}}
{{- end -}}
{{- join " " $parts -}}
{{- end -}}

{{/*
Add environment variables to configure private database
*/}}
{{- define "waldur.env.initdb" -}}
- name: PGHOST
  value: {{ include "waldur.postgresql.host" . }}

- name: PGPORT
  value: {{ include "waldur.postgresql.port" . }}

- name: PGUSER
  value: {{ include "waldur.postgresql.user" . }}

- name: PGDATABASE
  value: {{ include "waldur.postgresql.dbname" . }}

- name: PGPASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "waldur.postgresql.secret" . }}
      key: {{ include "waldur.postgresql.secret.passwordKey" . }}
{{- end -}}

{{/*
Add environment variables to configure database values and Sentry environment
*/}}
{{- define "waldur.credentials" -}}
- name: GLOBAL_SECRET_KEY
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.secretKeyExistingSecret.name | default "waldur-secret" }}
      key: {{ .Values.waldur.secretKeyExistingSecret.key | default "GLOBAL_SECRET_KEY" }}

{{ if or .Values.waldur.fieldEncryptionKey .Values.waldur.fieldEncryptionKeyExistingSecret.name }}
- name: FIELD_ENCRYPTION_KEY
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.fieldEncryptionKeyExistingSecret.name | default "waldur-secret" }}
      key: {{ .Values.waldur.fieldEncryptionKeyExistingSecret.key | default "FIELD_ENCRYPTION_KEY" }}
{{ end }}

{{ if or .Values.waldur.fieldEncryptionKeyFallbacks .Values.waldur.fieldEncryptionKeyFallbacksExistingSecret.name }}
- name: FIELD_ENCRYPTION_KEY_FALLBACKS
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.fieldEncryptionKeyFallbacksExistingSecret.name | default "waldur-secret" }}
      key: {{ .Values.waldur.fieldEncryptionKeyFallbacksExistingSecret.key | default "FIELD_ENCRYPTION_KEY_FALLBACKS" }}
{{ end }}

- name: POSTGRESQL_HOST
  value: {{ include "waldur.postgresql.host" . }}

- name: POSTGRESQL_PORT
  value: {{ include "waldur.postgresql.port" . }}

- name: POSTGRESQL_USER
{{ if and .Values.externalDB.enabled (not .Values.externalDB.username) }}
  valueFrom:
    secretKeyRef:
      name: {{ include "waldur.postgresql.secret" . }}
      key: username
{{ else }}
  value: {{ include "waldur.postgresql.user" . }}
{{ end }}

- name: POSTGRESQL_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "waldur.postgresql.secret" . }}
      key: {{ include "waldur.postgresql.secret.passwordKey" . }}

- name: POSTGRESQL_NAME
  value: {{ include "waldur.postgresql.dbname" . }}

{{ if .Values.readonlyDB.enabled }}
- name: POSTGRESQL_READONLY_USER
  {{ if .Values.readonlyDB.username }}
  valueFrom:
    secretKeyRef:
      name: waldur-secret
      key: READONLY_DB_USERNAME
  {{ else }}
  value: {{ include "waldur.postgresql.user" . }}
  {{ end }}

- name: POSTGRESQL_READONLY_PASSWORD
  {{ if .Values.readonlyDB.passwordExistingSecret.name }}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.readonlyDB.passwordExistingSecret.name }}
      key: {{ .Values.readonlyDB.passwordExistingSecret.key | default "READONLY_DB_PASSWORD" }}
  {{ else if .Values.readonlyDB.password }}
  valueFrom:
    secretKeyRef:
      name: waldur-secret
      key: READONLY_DB_PASSWORD
  {{ else }}
  valueFrom:
    secretKeyRef:
      name: {{ include "waldur.postgresql.secret" . }}
      key: {{ include "waldur.postgresql.secret.passwordKey" . }}
  {{ end }}
{{ end }}

{{/*
SMTP credentials. Emitted per key rather than as a pair: secrets.yaml writes MAIL_USER and
MAIL_PASSWORD under independent conditions, so a username configured without a password used to
leave EMAIL_PASSWORD pointing at a key that does not exist, and every pod including this helper
failed with CreateContainerConfigError. That is what previously took this block out of service.
optional: true keeps the same shape safe when an operator-supplied existingSecret carries only
one of the two keys — the variable is simply absent and the SMTP session stays anonymous, which
is the behaviour of an unconfigured relay rather than a crash loop.
*/}}
{{ if or .Values.waldur.mail.existingSecret.name .Values.waldur.mail.username }}
- name: EMAIL_USER
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.mail.existingSecret.name | default "waldur-secret" }}
      key: {{ .Values.waldur.mail.existingSecret.userKey | default "MAIL_USER" }}
      optional: true
{{ end }}

{{ if or .Values.waldur.mail.existingSecret.name .Values.waldur.mail.password }}
- name: EMAIL_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.mail.existingSecret.name | default "waldur-secret" }}
      key: {{ .Values.waldur.mail.existingSecret.passwordKey | default "MAIL_PASSWORD" }}
      optional: true
{{ end }}

- name: RABBITMQ_HOSTNAME
  value: {{ include "waldur.rabbitmq.rmqHost" . | quote }}
- name: RABBITMQ_USERNAME
  {{ if and .Values.rabbitmq.secret.name .Values.rabbitmq.secret.usernameKey }}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.rabbitmq.secret.name }}
      key: {{ .Values.rabbitmq.secret.usernameKey }}
  {{ else if and (kindIs "map" .Values.rabbitmq.auth.existingSecret) .Values.rabbitmq.auth.existingSecret.name }}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.rabbitmq.auth.existingSecret.name }}
      key: {{ .Values.rabbitmq.auth.existingSecret.usernameKey }}
  {{ else }}
  valueFrom:
    secretKeyRef:
      name: "waldur-secret"
      key: "RABBITMQ_USER"
  {{ end }}
- name: RABBITMQ_PASSWORD
  {{ if and .Values.rabbitmq.secret.name .Values.rabbitmq.secret.passwordKey }}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.rabbitmq.secret.name }}
      key: {{ .Values.rabbitmq.secret.passwordKey }}
  {{ else if and (kindIs "map" .Values.rabbitmq.auth.existingSecret) .Values.rabbitmq.auth.existingSecret.name }}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.rabbitmq.auth.existingSecret.name }}
      key: {{ .Values.rabbitmq.auth.existingSecret.passwordKey }}
  {{ else }}
  valueFrom:
    secretKeyRef:
      name: "waldur-secret"
      key: "RABBITMQ_PASSWORD"
  {{ end }}

{{ if .Values.waldur.sentryDSN }}
- name: SENTRY_DSN
  value: {{ .Values.waldur.sentryDSN | quote }}

- name: SENTRY_ENVIRONMENT
  valueFrom:
    fieldRef:
      fieldPath: metadata.namespace
{{ end }}

{{- if .Values.waldur.remoteEduteams.existingSecret.name -}}
- name: REMOTE_EDUTEAMS_REFRESH_TOKEN
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.refreshTokenKey }}
- name: REMOTE_EDUTEAMS_CLIENT_ID
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.clientIDKey }}
- name: REMOTE_EDUTEAMS_SECRET
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.clientSecretKey }}
- name: REMOTE_EDUTEAMS_USERINFO_URL
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.userinfoUrlKey }}
- name: REMOTE_EDUTEAMS_TOKEN_URL
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.tokenUrlKey }}
- name: REMOTE_EDUTEAMS_SSH_API_URL
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.sshApiUrlKey }}
- name: REMOTE_EDUTEAMS_SSH_API_USERNAME
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.sshApiUsernameKey }}
- name: REMOTE_EDUTEAMS_SSH_API_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.sshApiPasswordKey }}
{{- end -}}

{{- if .Values.waldur.ldap.passwordExistingSecret.name -}}
- name: AUTH_LDAP_BIND_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.ldap.passwordExistingSecret.name }}
      key: {{ .Values.waldur.ldap.passwordExistingSecret.key }}
{{- end -}}

{{- $pidDatacitePasswordSecret := dig "pid_datacite" "passwordSecret" (dict) .Values.waldur -}}
{{- if and (get $pidDatacitePasswordSecret "name") (get $pidDatacitePasswordSecret "key") }}
- name: DATACITE_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ get $pidDatacitePasswordSecret "name" }}
      key: {{ get $pidDatacitePasswordSecret "key" }}
{{- else if .Values.waldur.pid_datacite.password }}
- name: DATACITE_PASSWORD
  valueFrom:
    secretKeyRef:
      name: waldur-secret
      key: DATACITE_PASSWORD
{{- end -}}

{{- if .Values.waldur.paypal.existingSecret.name -}}
- name: PAYPAL_SECRET
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.paypal.existingSecret.name }}
      key: {{ .Values.waldur.paypal.existingSecret.secretKey }}
{{- end -}}

{{ if .Values.proxy.httpsProxy }}
- name: https_proxy
  value: {{ .Values.proxy.httpsProxy | quote }}
{{ end }}

{{ if .Values.proxy.httpProxy }}
- name: http_proxy
  value: {{ .Values.proxy.httpProxy | quote }}
{{ end }}

{{ if .Values.proxy.noProxy }}
- name: no_proxy
  value: {{ .Values.proxy.noProxy | quote }}
{{ end }}
{{- end -}}

{{/*
Determine imagePullPolicy based on image tag.
If tag is "latest", use "Always", otherwise use configured pullPolicy.
*/}}
{{- define "waldur.imagePullPolicy" -}}
{{- $tag := .tag -}}
{{- if eq $tag "latest" -}}
Always
{{- else -}}
{{ .Values.waldur.pullPolicy }}
{{- end -}}
{{- end -}}

{{/*
Determine imagePullPolicy based on full image string (image:tag).
If tag is "latest", use "Always", otherwise use configured pullPolicy.
*/}}
{{- define "waldur.imagePullPolicyFromImage" -}}
{{- $image := .image -}}
{{- $parts := splitList ":" $image -}}
{{- $tag := "latest" -}}
{{- if gt (len $parts) 1 -}}
{{- $tag = last $parts -}}
{{- end -}}
{{- if eq $tag "latest" -}}
Always
{{- else -}}
{{ .Values.waldur.pullPolicy }}
{{- end -}}
{{- end -}}

{{/*
Service IP family policy.

PreferDualStack so a Service gets a ClusterIP in every family the cluster
supports, and silently falls back to the single available family on an
IPv4-only or IPv6-only cluster — no per-cluster values needed. Without it
Services default to SingleStack on the cluster's *primary* family, so on a
dual-stack cluster IPv6 clients cannot reach them at all.

Deliberately not applied to the livekit-rtc LoadBalancer: dual-stack load
balancer support varies by cloud provider, and its media path is pinned to an
explicit node/external IP anyway.
*/}}
{{- define "waldur.serviceIpFamilyPolicy" -}}
ipFamilyPolicy: PreferDualStack
{{- end -}}

{{/*
Whether an ingress should redirect http -> https.

Takes a dict of "scheme" (the apiScheme / homeportScheme this ingress serves)
and "Values". Returns the string "true" or "false", so it can be used both as
an annotation value and in an `if`.

Redirecting is correct in exactly two cases:

  * the chart terminates TLS itself (`ingress.tls.enabled`), or
  * TLS is terminated upstream by a load balancer and the deployment is still
    addressed as https (`apiScheme` / `homeportScheme` set to https while
    `ingress.tls.enabled` stays false).

Redirecting unconditionally — which is what every ingress did before — breaks
the third case: a plain-http deployment (`ingress.tls.enabled: false` with both
schemes left at their "http" default) got a 301 to a scheme the chart had not
configured a certificate for, so homeport ended up on https while the API_URL
baked into its pod stayed http and the SPA could not bootstrap.
*/}}
{{- define "waldur.sslRedirect" -}}
{{- if or .Values.ingress.tls.enabled (eq .scheme "https") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Whether the traefik matrix-chain middleware has any member.

Unlike every other chain in the chart, matrix-chain's members are *all*
optional — the https redirect and the IP allow list, nothing else (the
homeserver, lk-jwt and LiveKit emit their own CORS headers, so no header
middleware is attached). Once the redirect became conditional, a plain-http
deployment with no whitelistSourceRange would render `middlewares:` with an
empty list, which Traefik rejects. So the chain object and the ingress
annotation that references it are both gated on this.
*/}}
{{- define "waldur.matrixChainEnabled" -}}
{{- if or (eq (include "waldur.sslRedirect" (dict "scheme" .Values.apiScheme "Values" .Values)) "true") .Values.ingress.whitelistSourceRange -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}
