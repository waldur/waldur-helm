# White-labeling instructions

To setup white-labeling, you can define next variables in `waldur/values.yaml` file:

* `shortPageTitle` - custom prefix for page title

* `modePageTitle` - custom page title

* `loginLogoPath` - path to custom `.png` image file

    for login page (should be in `waldur/` chart directory)

* `sidebarLogoPath` - path to custom `.png` image file

    for sidebar header (should be in `waldur/` chart directory)

* `sidebarLogoDarkPath` - path to custom `.png` image file

    for sidebar header in dark mode (should be in `waldur/` chart directory)

* `poweredByLogoPath` - path to custom `.png` image file

    for "powered by" part of login page (should be in `waldur/` chart directory)

* `faviconPath` - path to custom favicon `.png` image file

* `tosHtmlPath` - path to custom terms of service file (`tos.html`)

* `privacyHtmlPath` - path to custom privacy statement file (`privacy.html`)

* `brandColor` - Hex color definition is used in HomePort landing page for login button.

* `heroImagePath` - Relative path to image rendered at hero section of HomePort landing page.

* `heroLinkLabel` - Label for link in hero section of HomePort landing page. It can be lead to support site or blog post.

* `heroLinkUrl` - Link URL in hero section of HomePort landing page.

* `siteDescription` - text at hero section of HomePort landing page.

**NB:**

* the `*Path` values take place only if respectful `*Url` values are not specified.

    If both types are defined, the precedence is taken by `URL`(`*Url`) for all cases.

* all of imported files must be within chart root directory

Alternatively, TOS and PP files content can be provided as multiline values in `tosHtml` and `privacyHtml` options respectfully.
If defined, they take precedence over the aforementioned ones.

## Available countries

The countries offered in the organization creation dialog are set with
`waldur.marketplace.countries` — a list of ISO 3166-1 alpha-2 codes (plus the
synthetic `EU` entry):

```yaml
waldur:
  marketplace:
    countries: [EE, FI, US, JP, BR, AU]
```

By default the value is empty and the chart does not touch the setting, so a list
configured through *Administration → Branding* is preserved. Once the value is
set, the chart becomes the source of truth: it is reapplied by the
`init-whitelabeling` hook on every `helm upgrade`, overwriting changes made
through the admin UI.
