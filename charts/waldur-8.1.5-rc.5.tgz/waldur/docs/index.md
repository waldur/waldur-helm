# Waldur Helm chart configuration

Outline:

## Database Configuration

- **Production:** [PostgreSQL Operators (CloudNativePG & Zalando)](postgres-operator.md) ⭐ *Recommended*

- **Production:** [External DB Integration](external-db-integration.md)

- **Demo/Dev:** [Bundled PostgreSQL](postgres-db.md)

- [Postgres backup management](postgres-backup-management.md)

## Message Queue Configuration

- **Production:** [RabbitMQ Operator](rabbitmq-operator.md) ⭐ *Recommended*

- **Demo/Dev:** [Bundled RabbitMQ](rabbitmq.md)

## Additional Services

- [Components Overview](components.md)

## Configuration & Deployment

- [TLS](tls-config.md)

- [Content-Security-Policy](content-security-policy.md)

- [Gateway API](gateway-api.md)

- [Remote MCP server](mcp.md)

- [Outgoing email](mail.md)

- [White-labeling](whitelabeling.md)

- [Additional settings overrides, feature flags, and custom roles](configuration-overrides.md)

- [Custom Mastermind templates](mastermind-templates.md)

- [SAML2](saml2.md)

- [HPA](hpa.md)

- [IP whitelisting](ip-whitelisting.md)

- [Proxy setup](proxy-setup.md)

- [Trusting a private CA](trusted-ca-certificates.md)

- [Host aliasing](host-aliasing.md)
