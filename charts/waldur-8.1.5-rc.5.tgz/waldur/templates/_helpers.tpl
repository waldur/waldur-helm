{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "waldur.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "waldur.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "waldur.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "waldur.labels" -}}
app.kubernetes.io/name: {{ include "waldur.name" . }}
helm.sh/chart: {{ include "waldur.chart" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Set postgres version
*/}}
{{- define "waldur.postgresql.version" -}}
17
{{- end -}}

{{/*
Set postgres host
*/}}
{{- define "waldur.postgresql.host" -}}
{{- if .Values.externalDB.enabled -}}
{{ .Values.externalDB.serviceName }}
{{- else if .Values.postgresql.enabled -}}
"{{ .Release.Name }}-postgresql"
{{- else -}}
"postgresql-waldur"
{{- end -}}
{{- end -}}

{{/*
Set postgres port
*/}}
{{- define "waldur.postgresql.port" -}}
"5432"
{{- end -}}

{{/*
Set postgres secret
*/}}
{{- define "waldur.postgresql.secret" -}}
{{- if .Values.externalDB.enabled -}}
{{ .Values.externalDB.secretName }}
{{- else if .Values.postgresql.enabled -}}
"{{ .Release.Name }}-postgresql"
{{- else -}}
"postgresql-waldur"
{{- end -}}
{{- end -}}

{{/*
Set postgres secret password key.

The bundled subchart generates its admin secret with the key
"postgres-password". Operator-managed secrets differ: both CloudNativePG's
<cluster>-app secret and Zalando's *.credentials.postgresql.acid.zalan.do use
"password", which is the default for externalDB.passwordKey.
*/}}
{{- define "waldur.postgresql.secret.passwordKey" -}}
{{- if .Values.externalDB.enabled -}}
{{ .Values.externalDB.passwordKey | default "password" | quote }}
{{- else if .Values.postgresql.enabled -}}
"postgres-password"
{{- else -}}
"password"
{{- end -}}
{{- end -}}

{{/*
Set postgres database name
*/}}
{{- define "waldur.postgresql.dbname" -}}
{{- if .Values.postgresql.enabled -}}
{{ .Values.postgresql.auth.database | quote }}
{{- else if and .Values.externalDB.enabled .Values.externalDB.database -}}
{{ .Values.externalDB.database | quote }}
{{- else -}}
"waldur"
{{- end -}}
{{- end -}}

{{/*
Set postgres user
*/}}
{{- define "waldur.postgresql.user" -}}
{{- if .Values.postgresql.enabled -}}
{{ .Values.postgresql.auth.username | quote }}
{{- else if and .Values.externalDB.enabled .Values.externalDB.username -}}
{{ .Values.externalDB.username | quote }}
{{- else -}}
"waldur"
{{- end -}}
{{- end -}}

{{/*
Set rabbitmq host
*/}}
{{- define "waldur.rabbitmq.rmqHost" -}}
{{- $rmqHost := "" -}}
{{- if .Values.rabbitmq.enabled -}}
{{- $rmqHost = list .Release.Name "rabbitmq" | join "-" -}}
{{- else -}}
{{- $rmqHost = .Values.rabbitmq.host -}}
{{- end -}}
{{ $rmqHost }}
{{- end -}}


{{/*
Render a component's extraEnvVars list.
Usage: {{- include "waldur.extraEnvVars" .Values.api | nindent 12 }}
*/}}
{{- define "waldur.extraEnvVars" -}}
{{- with .extraEnvVars -}}
{{ toYaml . }}
{{- end -}}
{{- end -}}

{{/*
Render a component's envFrom entries from extraEnvVarsCM / extraEnvVarsSecret.
Skip the call site's envFrom: block entirely when both are empty.
Usage:
  {{- $envFrom := include "waldur.extraEnvFrom" .Values.api -}}
  {{- if $envFrom }}
  envFrom:
  {{- $envFrom | nindent 12 }}
  {{- end }}
*/}}
{{- define "waldur.extraEnvFrom" -}}
{{- if .extraEnvVarsCM }}
- configMapRef:
    name: {{ .extraEnvVarsCM }}
{{- end }}
{{- if .extraEnvVarsSecret }}
- secretRef:
    name: {{ .extraEnvVarsSecret }}
{{- end }}
{{- end -}}

{{/*
Render a component's extraVolumes list.
Usage: {{- include "waldur.extraVolumes" .Values.api | nindent 6 }}
*/}}
{{- define "waldur.extraVolumes" -}}
{{- with .extraVolumes -}}
{{ toYaml . }}
{{- end -}}
{{- end -}}

{{/*
Render a component's extraVolumeMounts list.
Usage: {{- include "waldur.extraVolumeMounts" .Values.api | nindent 12 }}
*/}}
{{- define "waldur.extraVolumeMounts" -}}
{{- with .extraVolumeMounts -}}
{{ toYaml . }}
{{- end -}}
{{- end -}}

{{/*
Render .Values.ingress.annotations as YAML key/value pairs, already indented
to sit inside an Ingress metadata.annotations block. Emits nothing when the
map is empty so the baseline render stays byte-identical.
Used by every ingress template so operators can add cross-cutting annotations
(e.g. external-dns.alpha.kubernetes.io/ttl: "60") without forking the chart.
Usage: {{- include "waldur.ingressAnnotations" . }}
*/}}
{{- define "waldur.ingressAnnotations" -}}
{{- with .Values.ingress.annotations -}}
{{- toYaml . | nindent 4 -}}
{{- end -}}
{{- end -}}

{{/*
Fail fast when gatewayAPI.enabled but the target cluster doesn't advertise the
Gateway API CRDs -- a clearer error than the apiserver's own "no matches for
kind HTTPRoute" during apply. Against a real cluster, .Capabilities.APIVersions
reflects what's actually installed; `helm template`/`helm lint` need an
explicit `--api-versions gateway.networking.k8s.io/v1/HTTPRoute` to simulate
that (see waldur/test/values-gateway.yaml usage in .gitlab-ci.yml).
Usage: {{- include "waldur.gatewayAPI.assertAvailable" . }}
*/}}
{{- define "waldur.gatewayAPI.assertAvailable" -}}
{{- if not (.Capabilities.APIVersions.Has "gateway.networking.k8s.io/v1/HTTPRoute") -}}
{{- fail "gatewayAPI.enabled is true, but the Gateway API CRDs (gateway.networking.k8s.io/v1) are not installed on the target cluster. Install them first: https://gateway-api.sigs.k8s.io/guides/#installing-gateway-api" -}}
{{- end -}}
{{- end -}}

{{/*
Render the parentRefs list for a chart-managed HTTPRoute: the chart's own
Gateway when gatewayAPI.createGateway is true, otherwise the operator-supplied
gatewayAPI.parentRefs (required non-empty in that case -- an HTTPRoute with no
parentRefs never attaches anywhere).
Usage:
  spec:
    parentRefs:
      {{- include "waldur.gatewayAPI.parentRefs" . | nindent 4 }}
*/}}
{{- define "waldur.gatewayAPI.parentRefs" -}}
{{- if .Values.gatewayAPI.createGateway -}}
- name: {{ include "waldur.fullname" . }}-gateway
{{- else if .Values.gatewayAPI.parentRefs -}}
{{- toYaml .Values.gatewayAPI.parentRefs -}}
{{- else -}}
{{- fail "gatewayAPI.enabled is true, but neither gatewayAPI.parentRefs nor gatewayAPI.createGateway is set -- HTTPRoutes need a Gateway to attach to." -}}
{{- end -}}
{{- end -}}

{{/*
Render .Values.gatewayAPI.annotations as YAML, for callers to nindent under
their own metadata.annotations. Emits nothing when the map is empty -- guard
with `if .Values.gatewayAPI.annotations` at the call site so an empty map
doesn't leave a dangling "annotations:" key.
Usage:
  {{- if .Values.gatewayAPI.annotations }}
  annotations:
    {{- include "waldur.gatewayAPI.annotations" . | nindent 4 }}
  {{- end }}
*/}}
{{- define "waldur.gatewayAPI.annotations" -}}
{{- toYaml .Values.gatewayAPI.annotations -}}
{{- end -}}

{{/*
Assemble GUNICORN_CMD_ARGS value from .Values.gunicorn.*. Returns empty when no field is set.
Usage:
  {{- $gun := include "waldur.gunicornCmdArgs" . -}}
  {{- if $gun }}
  - name: GUNICORN_CMD_ARGS
    value: {{ $gun | quote }}
  {{- end }}
*/}}
{{- define "waldur.gunicornCmdArgs" -}}
{{- $parts := list -}}
{{- with .Values.gunicorn -}}
{{- if .timeout }}{{- $parts = append $parts (printf "--timeout %v" .timeout) -}}{{- end -}}
{{- if .gracefulTimeout }}{{- $parts = append $parts (printf "--graceful-timeout %v" .gracefulTimeout) -}}{{- end -}}
{{- if .workers }}{{- $parts = append $parts (printf "--workers %v" .workers) -}}{{- end -}}
{{- if .keepalive }}{{- $parts = append $parts (printf "--keep-alive %v" .keepalive) -}}{{- end -}}
{{- if .maxRequests }}{{- $parts = append $parts (printf "--max-requests %v" .maxRequests) -}}{{- end -}}
{{- if .maxRequestsJitter }}{{- $parts = append $parts (printf "--max-requests-jitter %v" .maxRequestsJitter) -}}{{- end -}}
{{- if .extraArgs }}{{- $parts = append $parts .extraArgs -}}{{- end -}}
{{- end -}}
{{- join " " $parts -}}
{{- end -}}

{{/*
S3 credentials for the postgresBackup CronJobs and the restore pod.

With backupStorage.existingSecret.name set, both keys are read from that
Secret; otherwise they fall back to the plain backupStorage.accessKey and
backupStorage.secretKey values.
*/}}
{{- define "waldur.backupStorage.credentials" -}}
{{- $existing := .Values.backupStorage.existingSecret | default dict -}}
- name: MINIO_ACCESS_KEY
{{- if $existing.name }}
  valueFrom:
    secretKeyRef:
      name: {{ $existing.name | quote }}
      key: {{ $existing.accessKeyKey | default "AWS_ACCESS_KEY_ID" | quote }}
{{- else }}
  value: {{ .Values.backupStorage.accessKey | quote }}
{{- end }}
- name: MINIO_SECRET_KEY
{{- if $existing.name }}
  valueFrom:
    secretKeyRef:
      name: {{ $existing.name | quote }}
      key: {{ $existing.secretKeyKey | default "AWS_SECRET_ACCESS_KEY" | quote }}
{{- else }}
  value: {{ .Values.backupStorage.secretKey | quote }}
{{- end }}
{{- end -}}

{{/*
Add environment variables to configure private database
*/}}
{{- define "waldur.env.initdb" -}}
- name: PGHOST
  value: {{ include "waldur.postgresql.host" . }}

- name: PGPORT
  value: {{ include "waldur.postgresql.port" . }}

- name: PGUSER
  value: {{ include "waldur.postgresql.user" . }}

- name: PGDATABASE
  value: {{ include "waldur.postgresql.dbname" . }}

- name: PGPASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "waldur.postgresql.secret" . }}
      key: {{ include "waldur.postgresql.secret.passwordKey" . }}
{{- end -}}

{{/*
Add environment variables to configure database values and Sentry environment
*/}}
{{- define "waldur.credentials" -}}
- name: GLOBAL_SECRET_KEY
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.secretKeyExistingSecret.name | default "waldur-secret" }}
      key: {{ .Values.waldur.secretKeyExistingSecret.key | default "GLOBAL_SECRET_KEY" }}

{{ if or .Values.waldur.fieldEncryptionKey .Values.waldur.fieldEncryptionKeyExistingSecret.name }}
- name: FIELD_ENCRYPTION_KEY
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.fieldEncryptionKeyExistingSecret.name | default "waldur-secret" }}
      key: {{ .Values.waldur.fieldEncryptionKeyExistingSecret.key | default "FIELD_ENCRYPTION_KEY" }}
{{ end }}

{{ if or .Values.waldur.fieldEncryptionKeyFallbacks .Values.waldur.fieldEncryptionKeyFallbacksExistingSecret.name }}
- name: FIELD_ENCRYPTION_KEY_FALLBACKS
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.fieldEncryptionKeyFallbacksExistingSecret.name | default "waldur-secret" }}
      key: {{ .Values.waldur.fieldEncryptionKeyFallbacksExistingSecret.key | default "FIELD_ENCRYPTION_KEY_FALLBACKS" }}
{{ end }}

{{ if not .Values.waldur.telemetry.enabled }}
- name: WALDUR_TELEMETRY_ENABLED
  value: "false"
{{ end }}

- name: POSTGRESQL_HOST
  value: {{ include "waldur.postgresql.host" . }}

- name: POSTGRESQL_PORT
  value: {{ include "waldur.postgresql.port" . }}

- name: POSTGRESQL_USER
{{ if and .Values.externalDB.enabled (not .Values.externalDB.username) }}
  valueFrom:
    secretKeyRef:
      name: {{ include "waldur.postgresql.secret" . }}
      key: username
{{ else }}
  value: {{ include "waldur.postgresql.user" . }}
{{ end }}

- name: POSTGRESQL_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "waldur.postgresql.secret" . }}
      key: {{ include "waldur.postgresql.secret.passwordKey" . }}

- name: POSTGRESQL_NAME
  value: {{ include "waldur.postgresql.dbname" . }}

{{ if .Values.readonlyDB.enabled }}
- name: POSTGRESQL_READONLY_USER
  {{ if .Values.readonlyDB.username }}
  valueFrom:
    secretKeyRef:
      name: waldur-secret
      key: READONLY_DB_USERNAME
  {{ else }}
  value: {{ include "waldur.postgresql.user" . }}
  {{ end }}

- name: POSTGRESQL_READONLY_PASSWORD
  {{ if .Values.readonlyDB.passwordExistingSecret.name }}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.readonlyDB.passwordExistingSecret.name }}
      key: {{ .Values.readonlyDB.passwordExistingSecret.key | default "READONLY_DB_PASSWORD" }}
  {{ else if .Values.readonlyDB.password }}
  valueFrom:
    secretKeyRef:
      name: waldur-secret
      key: READONLY_DB_PASSWORD
  {{ else }}
  valueFrom:
    secretKeyRef:
      name: {{ include "waldur.postgresql.secret" . }}
      key: {{ include "waldur.postgresql.secret.passwordKey" . }}
  {{ end }}
{{ end }}

{{/*
SMTP credentials. Emitted per key rather than as a pair: secrets.yaml writes MAIL_USER and
MAIL_PASSWORD under independent conditions, so a username configured without a password used to
leave EMAIL_PASSWORD pointing at a key that does not exist, and every pod including this helper
failed with CreateContainerConfigError. That is what previously took this block out of service.
optional: true keeps the same shape safe when an operator-supplied existingSecret carries only
one of the two keys — the variable is simply absent and the SMTP session stays anonymous, which
is the behaviour of an unconfigured relay rather than a crash loop.
*/}}
{{ if or .Values.waldur.mail.existingSecret.name .Values.waldur.mail.username }}
- name: EMAIL_USER
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.mail.existingSecret.name | default "waldur-secret" }}
      key: {{ .Values.waldur.mail.existingSecret.userKey | default "MAIL_USER" }}
      optional: true
{{ end }}

{{ if or .Values.waldur.mail.existingSecret.name .Values.waldur.mail.password }}
- name: EMAIL_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.mail.existingSecret.name | default "waldur-secret" }}
      key: {{ .Values.waldur.mail.existingSecret.passwordKey | default "MAIL_PASSWORD" }}
      optional: true
{{ end }}

- name: RABBITMQ_HOSTNAME
  value: {{ include "waldur.rabbitmq.rmqHost" . | quote }}
- name: RABBITMQ_USERNAME
  {{ if and .Values.rabbitmq.secret.name .Values.rabbitmq.secret.usernameKey }}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.rabbitmq.secret.name }}
      key: {{ .Values.rabbitmq.secret.usernameKey }}
  {{ else if and (kindIs "map" .Values.rabbitmq.auth.existingSecret) .Values.rabbitmq.auth.existingSecret.name }}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.rabbitmq.auth.existingSecret.name }}
      key: {{ .Values.rabbitmq.auth.existingSecret.usernameKey }}
  {{ else }}
  valueFrom:
    secretKeyRef:
      name: "waldur-secret"
      key: "RABBITMQ_USER"
  {{ end }}
- name: RABBITMQ_PASSWORD
  {{ if and .Values.rabbitmq.secret.name .Values.rabbitmq.secret.passwordKey }}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.rabbitmq.secret.name }}
      key: {{ .Values.rabbitmq.secret.passwordKey }}
  {{ else if and (kindIs "map" .Values.rabbitmq.auth.existingSecret) .Values.rabbitmq.auth.existingSecret.name }}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.rabbitmq.auth.existingSecret.name }}
      key: {{ .Values.rabbitmq.auth.existingSecret.passwordKey }}
  {{ else }}
  valueFrom:
    secretKeyRef:
      name: "waldur-secret"
      key: "RABBITMQ_PASSWORD"
  {{ end }}

{{ if .Values.waldur.sentryDSN }}
- name: SENTRY_DSN
  value: {{ .Values.waldur.sentryDSN | quote }}

- name: SENTRY_ENVIRONMENT
  valueFrom:
    fieldRef:
      fieldPath: metadata.namespace
{{ end }}

{{- if .Values.waldur.remoteEduteams.existingSecret.name -}}
- name: REMOTE_EDUTEAMS_REFRESH_TOKEN
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.refreshTokenKey }}
- name: REMOTE_EDUTEAMS_CLIENT_ID
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.clientIDKey }}
- name: REMOTE_EDUTEAMS_SECRET
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.clientSecretKey }}
- name: REMOTE_EDUTEAMS_USERINFO_URL
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.userinfoUrlKey }}
- name: REMOTE_EDUTEAMS_TOKEN_URL
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.tokenUrlKey }}
- name: REMOTE_EDUTEAMS_SSH_API_URL
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.sshApiUrlKey }}
- name: REMOTE_EDUTEAMS_SSH_API_USERNAME
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.sshApiUsernameKey }}
- name: REMOTE_EDUTEAMS_SSH_API_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.remoteEduteams.existingSecret.name }}
      key: {{ .Values.waldur.remoteEduteams.existingSecret.sshApiPasswordKey }}
{{- end -}}

{{- if .Values.waldur.ldap.passwordExistingSecret.name -}}
- name: AUTH_LDAP_BIND_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .Values.waldur.ldap.passwordExistingSecret.name }}
      key: {{ .Values.waldur.ldap.passwordExistingSecret.key }}
{{- end -}}

{{- $pidDatacitePasswordSecret := dig "pid_datacite" "passwordSecret" (dict) .Values.waldur -}}
{{- if and (get $pidDatacitePasswordSecret "name") (get $pidDatacitePasswordSecret "key") }}
- name: DATACITE_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ get $pidDatacitePasswordSecret "name" }}
      key: {{ get $pidDatacitePasswordSecret "key" }}
{{- else if .Values.waldur.pid_datacite.password }}
- name: DATACITE_PASSWORD
  valueFrom:
    secretKeyRef:
      name: waldur-secret
      key: DATACITE_PASSWORD
{{- end -}}

{{ if .Values.proxy.httpsProxy }}
- name: https_proxy
  value: {{ .Values.proxy.httpsProxy | quote }}
{{ end }}

{{ if .Values.proxy.httpProxy }}
- name: http_proxy
  value: {{ .Values.proxy.httpProxy | quote }}
{{ end }}

{{ if .Values.proxy.noProxy }}
- name: no_proxy
  value: {{ .Values.proxy.noProxy | quote }}
{{ end }}
{{- end -}}

{{/*
Determine imagePullPolicy based on image tag.
If tag is "latest", use "Always", otherwise use configured pullPolicy.
*/}}
{{- define "waldur.imagePullPolicy" -}}
{{- $tag := .tag -}}
{{- if eq $tag "latest" -}}
Always
{{- else -}}
{{ .Values.waldur.pullPolicy }}
{{- end -}}
{{- end -}}

{{/*
Determine imagePullPolicy based on full image string (image:tag).
If tag is "latest", use "Always", otherwise use configured pullPolicy.
*/}}
{{- define "waldur.imagePullPolicyFromImage" -}}
{{- $image := .image -}}
{{- $parts := splitList ":" $image -}}
{{- $tag := "latest" -}}
{{- if gt (len $parts) 1 -}}
{{- $tag = last $parts -}}
{{- end -}}
{{- if eq $tag "latest" -}}
Always
{{- else -}}
{{ .Values.waldur.pullPolicy }}
{{- end -}}
{{- end -}}

{{/*
Service IP family policy.

PreferDualStack so a Service gets a ClusterIP in every family the cluster
supports, and silently falls back to the single available family on an
IPv4-only or IPv6-only cluster — no per-cluster values needed. Without it
Services default to SingleStack on the cluster's *primary* family, so on a
dual-stack cluster IPv6 clients cannot reach them at all.

Deliberately not applied to the livekit-rtc LoadBalancer: dual-stack load
balancer support varies by cloud provider, and its media path is pinned to an
explicit node/external IP anyway.
*/}}
{{- define "waldur.serviceIpFamilyPolicy" -}}
ipFamilyPolicy: PreferDualStack
{{- end -}}

{{/*
Whether an ingress should redirect http -> https.

Takes a dict of "scheme" (the apiScheme / homeportScheme this ingress serves)
and "Values". Returns the string "true" or "false", so it can be used both as
an annotation value and in an `if`.

Redirecting is correct in exactly two cases:

  * the chart terminates TLS itself (`ingress.tls.enabled`), or
  * TLS is terminated upstream by a load balancer and the deployment is still
    addressed as https (`apiScheme` / `homeportScheme` set to https while
    `ingress.tls.enabled` stays false).

Redirecting unconditionally — which is what every ingress did before — breaks
the third case: a plain-http deployment (`ingress.tls.enabled: false` with both
schemes left at their "http" default) got a 301 to a scheme the chart had not
configured a certificate for, so homeport ended up on https while the API_URL
baked into its pod stayed http and the SPA could not bootstrap.
*/}}
{{- define "waldur.sslRedirect" -}}
{{- if or .Values.ingress.tls.enabled (eq .scheme "https") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Whether the traefik matrix-chain middleware has any member.

Unlike every other chain in the chart, matrix-chain's members are *all*
optional — the https redirect and the IP allow list, nothing else (the
homeserver and LiveKit emit their own CORS headers, so no header middleware is
attached). Once the redirect became conditional, a plain-http
deployment with no whitelistSourceRange would render `middlewares:` with an
empty list, which Traefik rejects. So the chain object and the ingress
annotation that references it are both gated on this.
*/}}
{{- define "waldur.matrixChainEnabled" -}}
{{- if or (eq (include "waldur.sslRedirect" (dict "scheme" .Values.apiScheme "Values" .Values)) "true") .Values.ingress.whitelistSourceRange -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Exec command for the Celery worker's startup, liveness and readiness probes:
ping this pod's own worker (celery@<hostname>, the node name Celery derives
from socket.gethostname()) and exit non-zero, with the reason on stderr, if it
does not reply within 10s (Celery's default 1s RPC timeout is too low under
load).

This replaces `celery inspect -d celery@$HOSTNAME ping`, which never closes
its broker connections: the ping is published through Celery's pooled
producer, and the CLI exits with that pooled socket -- and its own -- still
open. RabbitMQ logs each one as "client unexpectedly closed TCP connection",
several times a minute per worker replica. Detaching the producer pool makes
the ping publish on the probe's own connection, which the `with` block closes
with a proper AMQP connection.close. (Closing the pools instead does not help:
kombu tears pooled sockets down without the AMQP close.) `producer_pool` is a
cached_property, so it is assigned directly: that holds even if the pool was
read earlier, whereas setting the private `_producer_pool` would not.
*/}}
{{- define "waldur.workerPingProbeCommand" -}}
- python3
- -c
- |
  import socket, sys
  from waldur_core.server.celeryconf import app
  app.control.mailbox.producer_pool = None
  worker = "celery@" + socket.gethostname()
  with app.connection() as conn:
      conn.ensure_connection(max_retries=1)
      replies = app.control.ping(destination=[worker], timeout=10, connection=conn)
  if not replies:
      sys.exit(worker + " did not reply to ping within 10s")
{{- end -}}

{{/*
Whether Matrix calls are configured: chat is on and LiveKit has a public
signaling URL (bundled or external). Gates the homeserver's RTC focus and the
LiveKit settings seeded into Waldur. Returns "true" or "false".

Calls carry bearer credentials in both directions: clients post their Matrix
OpenID token to Waldur's call token API (<apiScheme>://<apiHostname>), and get
back a LiveKit token they present on the signalling websocket (publicUrl). So
when calls are configured the render fails unless both transports are
encrypted — apiScheme "https" and a wss:// publicUrl — or
matrixChat.livekit.allowInsecureTransport opts out for a local or kind cluster.
*/}}
{{- define "waldur.matrixCallsEnabled" -}}
{{- if and .Values.matrixChat.enabled .Values.matrixChat.livekit.publicUrl -}}
{{- if not .Values.matrixChat.livekit.allowInsecureTransport -}}
{{- if not (hasPrefix "wss://" .Values.matrixChat.livekit.publicUrl) -}}
{{- fail (printf "matrixChat.livekit.publicUrl must be a wss:// URL, got %q: clients send their LiveKit call token on it. Set matrixChat.livekit.allowInsecureTransport=true to allow plaintext on a local or test cluster." .Values.matrixChat.livekit.publicUrl) -}}
{{- end -}}
{{- if ne .Values.apiScheme "https" -}}
{{- fail (printf "Matrix calls need apiScheme \"https\", got %q: clients post their Matrix OpenID token to the call token API at <apiScheme>://<apiHostname>/api/matrix/livekit. Set matrixChat.livekit.allowInsecureTransport=true to allow plaintext on a local or test cluster." .Values.apiScheme) -}}
{{- end -}}
{{- end -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
The call token API that Matrix clients use, served by Waldur's API. The
homeserver advertises it as the `livekit_service_url` of its RTC focus in
`.well-known/matrix/client`; Element Call and Waldur's chat drawer post to
<this>/get_token (and the legacy <this>/sfu/get) to get a LiveKit token.
*/}}
{{- define "waldur.matrixLivekitServiceUrl" -}}
{{- printf "%s://%s/api/matrix/livekit" .Values.apiScheme .Values.apiHostname -}}
{{- end -}}

{{/*
The LiveKit URL Waldur's backend calls (Twirp room API): the bundled server's
in-cluster Service, or the external server's public URL as http(s). Dotted,
because Waldur's URL settings reject single-label hostnames.
*/}}
{{- define "waldur.matrixLivekitInternalUrl" -}}
{{- $lk := .Values.matrixChat.livekit -}}
{{- if $lk.enabled -}}
{{- printf "http://livekit-signaling.%s.svc:%v" .Release.Namespace $lk.rtc.signalingPort -}}
{{- else -}}
{{- $lk.publicUrl | replace "wss://" "https://" | replace "ws://" "http://" -}}
{{- end -}}
{{- end -}}

{{/*
The homeport image renders the portal's Content-Security-Policy from its
environment; the proxies in front of it no longer set one. The helpers below
derive the sources the chart already knows about. An empty variable adds
nothing to the policy.
*/}}

{{/*
The policy the ingress controllers send on the pages they generate
themselves, which never reach homeport or mastermind and would otherwise carry
no policy at all. It is the policy mastermind sends on its API responses.
*/}}
{{- define "waldur.errorPageCsp" -}}
default-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'
{{- end -}}

{{/*
The statuses those pages come with: 400 and 431 (a request the backend's or
the controller's server would not parse, such as gunicorn's own error pages),
403 (the source range allow-list), 413 (the request body limit), 429 (rate
limiting) and 502-504 (the backend is down or slow).
*/}}
{{- define "waldur.errorPageStatuses" -}}
400 403 413 429 431 502 503 504
{{- end -}}

{{/*
The nginx configuration-snippet line that sets the policy on those statuses.
headers-more cannot test for a header the backend sent, so a backend response
with one of these statuses gets this policy in place of its own.
*/}}
{{- define "waldur.errorPageCspNginx" -}}
{{- include "waldur.errorPageCspNginxLine" (include "waldur.errorPageStatuses" .) -}}
{{- end -}}

{{/*
The same line for the ingresses in front of mastermind's API, without 400:
the browsable API answers a form with invalid input with a 400 page that needs
mastermind's page policy to load its scripts and styles and post the form
again. gunicorn's own 400 carries the API policy from the image, and
mastermind sends one on every response of its own.
*/}}
{{- define "waldur.errorPageCspNginxApi" -}}
{{- include "waldur.errorPageCspNginxLine" (without (splitList " " (include "waldur.errorPageStatuses" .)) "400" | join " ") -}}
{{- end -}}

{{- define "waldur.errorPageCspNginxLine" -}}
more_set_headers -s "{{ . }}" "Content-Security-Policy: {{ include "waldur.errorPageCsp" . }}";
{{- end -}}

{{/*
The HAProxy backend-config-snippet line that sets the policy on those
statuses. http-after-response also runs on responses HAProxy generates; a
backend response that carries a policy of its own keeps it.
*/}}
{{- define "waldur.errorPageCspHaproxy" -}}
http-after-response set-header Content-Security-Policy "{{ include "waldur.errorPageCsp" . }}" if { status {{ include "waldur.errorPageStatuses" . }} } !{ res.hdr(content-security-policy) -m found }
{{- end -}}

{{/*
The Matrix homeserver origin (CSP_MATRIX_URL): chat sync, media and images.
Empty when matrix chat is off.
*/}}
{{- define "waldur.cspMatrixUrl" -}}
{{- if and .Values.matrixChat.enabled .Values.matrixChat.homeserver.enabled .Values.matrixChat.homeserver.serverName -}}
{{- printf "%s://%s" .Values.apiScheme .Values.matrixChat.homeserver.serverName -}}
{{- end -}}
{{- end -}}

{{/*
The call signalling origins (CSP_MATRIX_CALL_URL): wss to the homeserver host,
where the bundled LiveKit's /rtc route sits, plus the LiveKit publicUrl's
origin when it is another one -- an operator-managed SFU, or a bundled one
whose RTC LoadBalancer has its own DNS name. The browser dials publicUrl
straight from the SPA, so an origin missing here refuses the call websocket
client-side with no server-side trace. publicUrl may carry a port or a path;
CSP sources are origins, so only scheme://host[:port] goes in. Empty when
matrix chat is off.
*/}}
{{- define "waldur.cspMatrixCallUrl" -}}
{{- $matrixUrl := include "waldur.cspMatrixUrl" . -}}
{{- if $matrixUrl -}}
{{- $origins := list (printf "wss://%s" .Values.matrixChat.homeserver.serverName) -}}
{{- with .Values.matrixChat.livekit.publicUrl -}}
{{- $url := urlParse . -}}
{{- $origin := printf "%s://%s" $url.scheme $url.host -}}
{{- if not (or (has $origin $origins) (eq $origin $matrixUrl)) -}}
{{- $origins = append $origins $origin -}}
{{- end -}}
{{- end -}}
{{- join " " $origins -}}
{{- end -}}
{{- end -}}

{{/*
The origin the SPA's Sentry SDK posts to (CSP_SENTRY_URL): customSentryURL when
set, else the origin of waldur.sentryDSN, which mastermind hands the SPA as
HOMEPORT_SENTRY_DSN.
*/}}
{{- define "waldur.cspSentryUrl" -}}
{{- if .Values.waldur.homeport.customSentryURL -}}
{{- .Values.waldur.homeport.customSentryURL -}}
{{- else if .Values.waldur.sentryDSN -}}
{{- $url := urlParse .Values.waldur.sentryDSN -}}
{{- printf "%s://%s" $url.scheme $url.host -}}
{{- end -}}
{{- end -}}

{{/*
A waldur.homeport.csp switch: "true" when it is true, empty when it is false
or unset, and a failed render for anything else. Compared as text, because a
quoted "false" (--set-string, forced strings in a GitOps tool) is a non-empty
string, which a plain `if` reads as true.
Usage: {{ include "waldur.cspBool" (dict "name" "reportOnly" "value" $csp.reportOnly) }}
*/}}
{{- define "waldur.cspBool" -}}
{{- $text := .value | toString | lower -}}
{{- if eq $text "true" -}}
true
{{- else if not (has $text (list "false" "" "<nil>")) -}}
{{- fail (printf "waldur.homeport.csp.%s must be true or false, not %q" .name (toString .value)) -}}
{{- end -}}
{{- end -}}

{{/*
CSP sources as one space-separated string: a value may be a string or a list.
*/}}
{{- define "waldur.cspSources" -}}
{{- if kindIs "slice" . -}}
{{- join " " . -}}
{{- else if . -}}
{{- toString . -}}
{{- end -}}
{{- end -}}

{{/*
Fails the render on a CSP value the homeport image would refuse at start,
which would leave the new pod crash-looping and the rollout hung. Mirrors the
image's entrypoint: whitespace (a YAML block's newlines) is folded into
spaces first; a source list may not hold " \ $ , ; or a control character, a
whole policy may hold ";" between its directives, and a URI may not hold
whitespace or ' either.
Usage: include "waldur.cspCheckValue" (dict "from" "<value path>" "value" $v "kind" "sources|policy|uri")
*/}}
{{- define "waldur.cspCheckValue" -}}
{{- $value := regexReplaceAll `[[:space:]]+` (toString .value) " " | trim -}}
{{- $refused := dict "sources" `["\\$,;[:cntrl:]]` "policy" `["\\$,[:cntrl:]]` "uri" `["'\\$,; [:cntrl:]]` -}}
{{- $named := dict "sources" `" \ $ , ;` "policy" `" \ $ ,` "uri" `whitespace, ' " \ $ , ;` -}}
{{- $hint := dict "sources" "Separate sources with spaces, or give a list." "policy" "Separate directives with \";\"." "uri" "Give one URL." -}}
{{- if regexMatch (get $refused .kind) $value -}}
{{- fail (printf "%s: %q may not contain %s or a control character; the homeport image refuses it and does not start. %s" .from $value (get $named .kind) (get $hint .kind)) -}}
{{- end -}}
{{- end -}}

{{/*
Fails the render on a policy override the homeport image would refuse: one
with no directive, one where a line ended without ";" so that two directives
run together (a newline does not end a directive), one that does not state
object-src, base-uri and frame-ancestors, and one that states report-uri (or
report-to) while reportUri (or reportTo) adds it as well.
Usage: include "waldur.cspCheckPolicy" (dict "policy" $policy "reportUri" $uri "reportTo" $bool)
*/}}
{{- define "waldur.cspCheckPolicy" -}}
{{- $from := "waldur.homeport.csp.policy" -}}
{{- $policy := regexReplaceAll `[[:space:]]+` (toString .policy) " " | trim | lower -}}
{{- $policy = regexReplaceAll ` *; *` $policy "; " -}}
{{- $policy = regexReplaceAll `^[; ]+|[; ]+$` $policy "" -}}
{{- if not $policy -}}
{{- fail (printf "%s: it holds no directive" $from) -}}
{{- end -}}
{{- $names := list -}}
{{- $alsoDirectives := list "base-uri" "form-action" "frame-ancestors" "report-uri" "report-to" "sandbox" "upgrade-insecure-requests" -}}
{{- range splitList ";" $policy -}}
{{- $fields := splitList " " (trim .) | compact -}}
{{- if $fields -}}
{{- $directive := first $fields -}}
{{- $names = append $names $directive -}}
{{- range rest $fields -}}
{{- if and (regexMatch `^[a-z]+(-[a-z]+)*$` .) (or (regexMatch `-src(-elem|-attr)?$` .) (has . $alsoDirectives)) -}}
{{- fail (printf "%s: %s sits inside %s; end every directive with \";\", a newline does not" $from . $directive) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $missing := list -}}
{{- range list "object-src" "base-uri" "frame-ancestors" -}}
{{- if not (has . $names) -}}
{{- $missing = append $missing . -}}
{{- end -}}
{{- end -}}
{{- if $missing -}}
{{- fail (printf "%s: it lacks %s; every policy must state object-src, base-uri and frame-ancestors" $from (join " " $missing)) -}}
{{- end -}}
{{- if .reportUri -}}
{{- if has "report-uri" $names -}}
{{- fail (printf "%s: it states report-uri and waldur.homeport.csp.reportUri is set too; give the endpoint in one of them" $from) -}}
{{- end -}}
{{- if and .reportTo (has "report-to" $names) -}}
{{- fail (printf "%s: it states report-to and waldur.homeport.csp.reportTo is set too; give it in one of them" $from) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The homeport container's CSP environment, one entry per non-empty variable.
waldur.homeport.csp.extra keys are directive names (connect-src, or
CONNECT_SRC); each becomes CSP_<DIRECTIVE>_EXTRA. A directive the image does
not know fails the render, because the variable would otherwise be ignored
without a trace. So does a value the image would refuse at start (see
waldur.cspCheckValue and waldur.cspCheckPolicy).
Each entry: variable name, value, kind of value, and the chart value it comes
from (for error messages).
*/}}
{{- define "waldur.homeportCspEnv" -}}
{{- $csp := .Values.waldur.homeport.csp | default dict -}}
{{- $hp := .Values.waldur.homeport -}}
{{- $env := list -}}
{{- $env = append $env (list "CSP_SENTRY_URL" (include "waldur.cspSentryUrl" .) "sources" "waldur.homeport.customSentryURL (or waldur.sentryDSN)") -}}
{{- $env = append $env (list "CSP_MATOMO_URL" $hp.matomoUrlBase "sources" "waldur.homeport.matomoUrlBase") -}}
{{- $env = append $env (list "CSP_MATRIX_URL" (include "waldur.cspMatrixUrl" .) "sources" "matrixChat.homeserver.serverName") -}}
{{- $env = append $env (list "CSP_MATRIX_CALL_URL" (include "waldur.cspMatrixCallUrl" .) "sources" "matrixChat.livekit.publicUrl") -}}
{{- $env = append $env (list "CSP_INFERENCE_URL" $hp.inferencePlaygroundURL "sources" "waldur.homeport.inferencePlaygroundURL") -}}
{{- $env = append $env (list "CSP_FORM_ACTION" (include "waldur.cspSources" $csp.formAction) "sources" "waldur.homeport.csp.formAction") -}}
{{- $reportOnly := include "waldur.cspBool" (dict "name" "reportOnly" "value" $csp.reportOnly) -}}
{{- $env = append $env (list "CSP_REPORT_ONLY" $reportOnly "flag" "waldur.homeport.csp.reportOnly") -}}
{{- $env = append $env (list "CSP_REPORT_URI" $csp.reportUri "uri" "waldur.homeport.csp.reportUri") -}}
{{- $reportTo := include "waldur.cspBool" (dict "name" "reportTo" "value" $csp.reportTo) -}}
{{- $env = append $env (list "CSP_REPORT_TO" $reportTo "flag" "waldur.homeport.csp.reportTo") -}}
{{- $known := list "DEFAULT_SRC" "SCRIPT_SRC" "STYLE_SRC" "IMG_SRC" "CONNECT_SRC" "FONT_SRC" "MEDIA_SRC" "WORKER_SRC" "FRAME_SRC" "FORM_ACTION" -}}
{{- range $directive, $sources := ($csp.extra | default dict) -}}
{{- $key := $directive | replace "-" "_" | upper -}}
{{- if not (has $key $known) -}}
{{- fail (printf "waldur.homeport.csp.extra: unknown directive %q; use one of %s (lower case with dashes also works)" $directive (join ", " $known)) -}}
{{- end -}}
{{- $env = append $env (list (printf "CSP_%s_EXTRA" $key) (include "waldur.cspSources" $sources) "sources" (printf "waldur.homeport.csp.extra.%s" $directive)) -}}
{{- end -}}
{{- $env = append $env (list "CSP_POLICY" $csp.policy "policy" "waldur.homeport.csp.policy") -}}
{{- range $env -}}
{{- if and (index . 1) (ne (index . 2) "flag") -}}
{{- $_ := include "waldur.cspCheckValue" (dict "from" (index . 3) "value" (index . 1) "kind" (index . 2)) -}}
{{- end -}}
{{- end -}}
{{- if $csp.policy -}}
{{- $_ := include "waldur.cspCheckPolicy" (dict "policy" $csp.policy "reportUri" $csp.reportUri "reportTo" $reportTo) -}}
{{- end -}}
{{- range $env -}}
{{- if index . 1 }}
- name: {{ index . 0 }}
  value: {{ index . 1 | toString | quote }}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The appservice bot's Matrix localpart: MATRIX_APPSERVICE_SENDER_LOCALPART from
waldur.settingsOverrides, else matrixChat.setup.botLocalpart where the chart
has one, else Waldur's default. A value changed only in Waldur's settings is
invisible here.
*/}}
{{- define "waldur.matrixBotLocalpart" -}}
{{- index .Values.waldur.settingsOverrides "MATRIX_APPSERVICE_SENDER_LOCALPART" | default (dig "setup" "botLocalpart" "waldur-bot" .Values.matrixChat) -}}
{{- end -}}

{{/*
Init container that blocks the main process until the schema matches this image.

Migrations run only in the beat Deployment (waldur-mastermind-migrate, args:
initdb). Helm and Argo CD update the API, worker, and web-shell Deployments
in the same sync, so without this gate the new image can answer requests,
consume Celery tasks, or open a shell while those migrations are still
running. The pod stays unready until this container exits 0.

`migrate --check` exits non-zero while any migration known to this image is
unapplied, and also while the database is unreachable. It does not apply
migrations, so beat remains the only migrator. The first check runs before
any sleep: a restart against an already-current schema pays for one Django
boot and continues.

Context is a dict:
  root:      chart root context (image, credentials, initdbWaitTimeout)
  resources: requests/limits for this pod's main container
  env:       optional env list as YAML, instead of all of waldur.credentials
  securityContext: optional container securityContext
*/}}
{{- define "waldur.waitForMigrationsInitContainer" -}}
- name: wait-for-migrations
  {{- if .root.Values.waldur.imageDigest }}
  image: {{ .root.Values.global.imageRegistry }}/{{ .root.Values.waldur.imageName }}@{{ .root.Values.waldur.imageDigest }}
  {{- else }}
  image: {{ .root.Values.global.imageRegistry }}/{{ .root.Values.waldur.imageName }}:{{ .root.Values.waldur.imageTag }}
  {{- end }}
  imagePullPolicy: {{ include "waldur.imagePullPolicy" (dict "tag" .root.Values.waldur.imageTag "Values" .root.Values) }}
  {{- with .securityContext }}
  securityContext:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  command:
    - /bin/bash
    - -ec
    - |
      DEADLINE=$(( $(date +%s) + {{ .root.Values.waldur.initdbWaitTimeout | default 2700 | int }} ))
      until waldur migrate --check >/dev/null 2>&1; do
          if [ "$(date +%s)" -ge "$DEADLINE" ]; then
              echo "ERROR: migrations still incomplete after {{ .root.Values.waldur.initdbWaitTimeout | default 2700 | int }}s." >&2
              echo "ERROR: the beat pod runs them in its waldur-mastermind-migrate initContainer -- check it." >&2
              # Surface the reason rather than just the timeout.
              waldur migrate --check || true
              exit 1
          fi
          echo "INFO: waiting for migrations to complete..."
          # 30s, not a tighter loop: `migrate --check` boots the whole
          # Django app registry every time (~4s measured), on the node
          # that is busy running the migrations. Each API, worker, and
          # web-shell replica polls on its own, so a 10s interval
          # multiplies that cost by the replica count. One hook polling
          # every 10s spent ~234s of CPU across 60 boots during one 834s
          # wait; 30s cuts that, and the first check runs before any
          # sleep, so an upgrade against an already-current schema --
          # the common case -- still proceeds immediately.
          sleep 30
      done
      echo "INFO: schema is up to date."
  env:
    {{- .env | default (include "waldur.credentials" .root) | nindent 4 }}
  volumeMounts:
    - name: api-override
      mountPath: /etc/waldur/override.conf.py
      subPath: override.conf.py
  resources:
    {{- toYaml .resources | nindent 4 }}
{{- end -}}

{{/*
spec.replicas of a Deployment an HPA may scale, as a "replicas: N" line or
nothing. Context: dict with "root", "name" (the Deployment), "count" (its
replicaCount) and "hpa" (whether its HPA is enabled).

Without the HPA it is the configured count. With it, the HPA owns the count:
rendering replicaCount would reset what the HPA scaled to on every upgrade.
The live count is rendered instead, so the manifest matches the cluster and
Helm's three-way merge leaves it alone. Omitting the field would not do: once
a previous manifest set it, Helm deletes it and Kubernetes defaults it to 1.
Where lookup sees no cluster (helm template, client-side dry runs, Argo CD)
or the Deployment does not exist yet, the field is omitted. A live 0 is not
carried over: the HPA is inactive there, and a raised replicaCount must
bring the Deployment back. replicaCount 0 is always rendered, since an HPA
never scales up from 0, which keeps a passive standby down.
*/}}
{{- define "waldur.deploymentReplicas" -}}
{{- $count := .count | int -}}
{{- if or (not .hpa) (eq $count 0) -}}
replicas: {{ $count }}
{{- else -}}
{{- $live := lookup "apps/v1" "Deployment" .root.Release.Namespace .name | default dict -}}
{{- $liveReplicas := dig "spec" "replicas" 0 $live | int -}}
{{- if gt $liveReplicas 0 -}}
replicas: {{ $liveReplicas }}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Whether a value is set: neither missing, null nor an empty string. A false
boolean is set. Takes the value itself.
*/}}
{{- define "waldur.isSet" -}}
{{- if and (not (kindIs "invalid" .)) (ne (toString .) "") -}}
true
{{- end -}}
{{- end -}}

{{/*
Demo preset settings for the API and the worker, whether or not the portal
offers presets: the `waldur demo_presets` command in a pod uses them too.
Takes the root context.
*/}}
{{- define "waldur.demoPresets.env" -}}
{{- $p := .Values.waldur.demoPresets -}}
{{- if $p.presetsConfigMap }}
- name: WALDUR_DEMO_PRESETS_EXTRA_DIRS
  value: /etc/waldur/presets
{{- end }}
{{- if $p.overlay }}
- name: WALDUR_DEMO_PRESETS_OVERLAY
  value: {{ $p.overlay | quote }}
{{- end }}
{{- if $p.staffPassword.existingSecret }}
- name: WALDUR_DEMO_PRESETS_STAFF_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ $p.staffPassword.existingSecret | quote }}
      key: {{ $p.staffPassword.key | default "password" | quote }}
{{- end }}
{{- end -}}

{{- define "waldur.demoPresets.volumeMounts" -}}
{{- if .Values.waldur.demoPresets.presetsConfigMap }}
- name: demo-presets
  mountPath: /etc/waldur/presets
  readOnly: true
{{- end }}
{{- end -}}

{{- define "waldur.demoPresets.volumes" -}}
{{- with .Values.waldur.demoPresets.presetsConfigMap }}
- name: demo-presets
  configMap:
    name: {{ . | quote }}
{{- end }}
{{- end -}}

{{/*
The paths routed for the remote MCP server on the API hosts, shared by its
Ingresses and HTTPRoutes: "mcp" goes to the MCP pods, "oauth" to the API.
Only these /oauth paths: /oauth/consent is the portal's page, and the portal
often shares the API's host.
Usage: {{- $paths := include "waldur.mcp.paths" . | fromJson }}
*/}}
{{- define "waldur.mcp.paths" -}}
{{- $mcp := list "/mcp" "/.well-known/oauth-protected-resource" -}}
{{- $oauth := list "/.well-known/oauth-authorization-server" "/oauth/authorize" "/oauth/token" "/oauth/revoke_token" "/oauth/register" -}}
{{- dict "mcp" $mcp "oauth" $oauth | toJson -}}
{{- end -}}

{{/*
The part of waldur.credentials the MCP server reads: the database, the broker
its events go through, the Django and field encryption keys, Sentry and the
outbound proxy. Not the mail, LDAP, eduTEAMS or DataCite credentials the API
and workers use. An allowlist, so credentials added to waldur.credentials
later stay out of the MCP pod until they are added here.
*/}}
{{- define "waldur.mcp.credentials" -}}
{{- $env := list -}}
{{- range (include "waldur.credentials" . | fromYamlArray) -}}
{{- if regexMatch "^(GLOBAL_SECRET_KEY|FIELD_ENCRYPTION_KEY(_FALLBACKS)?|POSTGRESQL_[A-Z_]+|RABBITMQ_[A-Z_]+|SENTRY_[A-Z_]+|WALDUR_TELEMETRY_ENABLED|https?_proxy|no_proxy)$" .name -}}
{{- $env = append $env . -}}
{{- end -}}
{{- end -}}
{{- toYaml $env -}}
{{- end -}}
